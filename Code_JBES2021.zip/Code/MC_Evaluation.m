% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

%%  This file generates Table 1, Table 3 and Table 5.
% Table 1 uses the Monte Carlo simulation MC_local.m and the corresponding
% output MC_local.mat.

% Table 3 uses the Monte Carlo simulation MC_skewness.m and MC_kurtosis.m and the corresponding
% output MC_skewness.mat and MC_kurtosis.mat.

% Table 5 uses the Monte Carlo simulation MC.m and the corresponding
% output MC.mat.

% The file also generates Table 1 in the online Appendix, which uses the
% Monte Carlo simulation in MC.m and the correpsonding output MC.mat.

%%  Table 1
clc
clear
close all
addpath(genpath('./Functions'));
 
load('MCResults/MC_local.mat') 


% Chose an element to evaluate
element = [1,1];

% Choose time index of Tloop  
time_it = 1  
eval_SVARGMM_2_T1 =  MCEvaluation(B, SVARGMM_2(:,:,:,:,time_it), element,Tloop(time_it));
eval_SVARGMM_3_T1 =  MCEvaluation(B, SVARGMM_3(:,:,:,:,time_it), element,Tloop(time_it));
eval_GMMLL_T1 =  MCEvaluation(B, GMMLL(:,:,:,:,time_it), element,Tloop(time_it));
eval_PML_T1 =  MCEvaluation(B, PML(:,:,:,:,time_it), element,Tloop(time_it));

% Choose time index of Tloop  
time_it = 2  
eval_SVARGMM_2_T2 =  MCEvaluation(B, SVARGMM_2(:,:,:,:,time_it), element,Tloop(time_it));
eval_SVARGMM_3_T2 =  MCEvaluation(B, SVARGMM_3(:,:,:,:,time_it), element,Tloop(time_it));
eval_GMMLL_T2 =  MCEvaluation(B, GMMLL(:,:,:,:,time_it), element,Tloop(time_it));
eval_PML_T2 =  MCEvaluation(B, PML(:,:,:,:,time_it), element,Tloop(time_it));

% Choose time index of Tloop  
time_it = 3 
eval_SVARGMM_2_T3 =  MCEvaluation(B, SVARGMM_2(:,:,:,:,time_it), element,Tloop(time_it));
eval_SVARGMM_3_T3 =  MCEvaluation(B, SVARGMM_3(:,:,:,:,time_it), element,Tloop(time_it));
eval_GMMLL_T3 =  MCEvaluation(B, GMMLL(:,:,:,:,time_it), element,Tloop(time_it));
eval_PML_T3 =  MCEvaluation(B, PML(:,:,:,:,time_it), element,Tloop(time_it));

% Latex table  
outputelements = [1,4];
data = []
data.row = {      ''  ''  ''  ''     }
data.rowname = {    '\hat{A}(W^{\text{2-step}})'  '\hat{A}(W^{fast}) '    '\text{GMM}_{LL}'  '\text{PML}'    }
data.estimator = {...  
                  [   
                    table2array(eval_SVARGMM_2_T1(1,outputelements))',...
                    table2array(eval_SVARGMM_2_T1(2,outputelements))',... 
                     table2array(eval_SVARGMM_2_T1(3,outputelements))', ...  
                    table2array(eval_SVARGMM_2_T2(1,outputelements))',...
                    table2array(eval_SVARGMM_2_T2(2,outputelements))',... 
                     table2array(eval_SVARGMM_2_T2(3,outputelements))', ...  
                    table2array(eval_SVARGMM_2_T3(1,outputelements))',...
                    table2array(eval_SVARGMM_2_T3(2,outputelements))',... 
                     table2array(eval_SVARGMM_2_T3(3,outputelements))', ... 
                    ]   
                  ,
                  [   
                    table2array(eval_SVARGMM_3_T1(1,outputelements))',...
                    table2array(eval_SVARGMM_3_T1(2,outputelements))',... 
                     table2array(eval_SVARGMM_3_T1(3,outputelements))', ...  
                    table2array(eval_SVARGMM_3_T2(1,outputelements))',...
                    table2array(eval_SVARGMM_3_T2(2,outputelements))',... 
                     table2array(eval_SVARGMM_3_T2(3,outputelements))', ...  
                    table2array(eval_SVARGMM_3_T3(1,outputelements))',...
                    table2array(eval_SVARGMM_3_T3(2,outputelements))',... 
                     table2array(eval_SVARGMM_3_T3(3,outputelements))', ... 
                    ]   
                    , 
                  [   
                    table2array(eval_GMMLL_T1(1,outputelements))',...
                    table2array(eval_GMMLL_T1(2,outputelements))',... 
                     table2array(eval_GMMLL_T1(3,outputelements))', ...  
                    table2array(eval_GMMLL_T2(1,outputelements))',...
                    table2array(eval_GMMLL_T2(2,outputelements))',... 
                     table2array(eval_GMMLL_T2(3,outputelements))', ...  
                    table2array(eval_GMMLL_T3(1,outputelements))',...
                    table2array(eval_GMMLL_T3(2,outputelements))',... 
                     table2array(eval_GMMLL_T3(3,outputelements))', ... 
                    ]   
                    , 
                  [   
                    table2array(eval_PML_T1(1,outputelements))',...
                    table2array(eval_PML_T1(2,outputelements))',... 
                     table2array(eval_PML_T1(3,outputelements))', ...  
                    table2array(eval_PML_T2(1,outputelements))',...
                    table2array(eval_PML_T2(2,outputelements))',... 
                     table2array(eval_PML_T2(3,outputelements))', ...  
                    table2array(eval_PML_T3(1,outputelements))',...
                    table2array(eval_PML_T3(2,outputelements))',... 
                     table2array(eval_PML_T3(3,outputelements))', ... 
                    ]      
                  }
              
              
latex  = generateLatexTable(data)


 
 
 %% Table 3 (first part)
clc
clear
close all
addpath(genpath('./Functions'));

load('MCResults/MC_skewness.mat')
% Chose an element to evaluate
element = [1,1];

% Choose time index of Tloop  
time_it = 1 
evaluation_A_GMM_r3wf_T1 =  MCEvaluation(B, FSVARGMM(:,:,:,:,time_it), element,Tloop(time_it)) 

% Choose time index of Tloop  
time_it = 2 
evaluation_A_GMM_r3wf_T2 =  MCEvaluation(B, FSVARGMM(:,:,:,:,time_it), element,Tloop(time_it)) 

% Choose time index of Tloop  
time_it = 3 
evaluation_A_GMM_r3wf_T3 =  MCEvaluation(B, FSVARGMM(:,:,:,:,time_it), element,Tloop(time_it)) 

% Latex table  
outputelements = [1,2];
data = []
data.row = {''        }
data.rowname = {   '\hat{A}_{r=3} (W^{fast}) '  }
data.estimator = {... 
                  [   
                    table2array(evaluation_A_GMM_r3wf_T1(1:3,outputelements))',... 
                    table2array(evaluation_A_GMM_r3wf_T2(1:3,outputelements))',... 
                    table2array(evaluation_A_GMM_r3wf_T3(1:3,outputelements))' 
                    ]    
                  }
              
              
latex  = generateLatexTable(data)



%% Table 3 (second part)
clc
clear
close all
addpath(genpath('./Functions'));

load('MCResults/MC_kurtosis.mat')
% Chose an element to evaluate
element = [1,1];

% Choose time index of Tloop  
time_it = 1 
evaluation_A_GMM_r4wf_T1 =  MCEvaluation(B, FSVARGMM(:,:,:,:,time_it), element,Tloop(time_it)) 

% Choose time index of Tloop  
time_it = 2 
evaluation_A_GMM_r4wf_T2 =  MCEvaluation(B, FSVARGMM(:,:,:,:,time_it), element,Tloop(time_it)) 

% Choose time index of Tloop  
time_it = 3 
evaluation_A_GMM_r4wf_T3 =  MCEvaluation(B, FSVARGMM(:,:,:,:,time_it), element,Tloop(time_it)) 

% Latex table  
outputelements = [1,2];
data = []
data.row = {''      }
data.rowname = { '\hat{A}_{r=4} (W^{fast})'   }
data.estimator = {... 
                  [   
                    table2array(evaluation_A_GMM_r4wf_T1(1:3,outputelements))',... 
                    table2array(evaluation_A_GMM_r4wf_T2(1:3,outputelements))',... 
                    table2array(evaluation_A_GMM_r4wf_T3(1:3,outputelements))' 
                    ]    
                  }
              
latex  = generateLatexTable(data)

%% Table 5
clc
clear
close all
addpath(genpath('./Functions'));

load('MCResults/MC.mat') 


% Chose an element to evaluate
element = [1,1];

% Choose time index of Tloop  
time_it = 1  
eval_SVARGMM_2_T1 =  MCEvaluation(B, SVARGMM_2(:,:,:,:,time_it), element,Tloop(time_it));
eval_SVARGMM_3_T1 =  MCEvaluation(B, SVARGMM_3(:,:,:,:,time_it), element,Tloop(time_it));
eval_GMMLL_T1 =  MCEvaluation(B, GMMLL(:,:,:,:,time_it), element,Tloop(time_it));
eval_PML_T1 =  MCEvaluation(B, PML(:,:,:,:,time_it), element,Tloop(time_it));

% Choose time index of Tloop  
time_it = 2  
eval_SVARGMM_2_T2 =  MCEvaluation(B, SVARGMM_2(:,:,:,:,time_it), element,Tloop(time_it));
eval_SVARGMM_3_T2 =  MCEvaluation(B, SVARGMM_3(:,:,:,:,time_it), element,Tloop(time_it));
eval_GMMLL_T2 =  MCEvaluation(B, GMMLL(:,:,:,:,time_it), element,Tloop(time_it));
eval_PML_T2 =  MCEvaluation(B, PML(:,:,:,:,time_it), element,Tloop(time_it));

% Choose time index of Tloop  
time_it = 3 
eval_SVARGMM_2_T3 =  MCEvaluation(B, SVARGMM_2(:,:,:,:,time_it), element,Tloop(time_it));
eval_SVARGMM_3_T3 =  MCEvaluation(B, SVARGMM_3(:,:,:,:,time_it), element,Tloop(time_it));
eval_GMMLL_T3 =  MCEvaluation(B, GMMLL(:,:,:,:,time_it), element,Tloop(time_it));
eval_PML_T3 =  MCEvaluation(B, PML(:,:,:,:,time_it), element,Tloop(time_it));

% Latex table  
outputelements = [1,4];
data = []
data.row = {      ''  ''  ''  ''     }
data.rowname = {    '\hat{A}(W^{\text{2-step}})'  '\hat{A}(W^{fast}) '    '\text{GMM}_{LL}'  '\text{PML}'    }
data.estimator = {...  
                  [   
                    table2array(eval_SVARGMM_2_T1(1,outputelements))',...
                    table2array(eval_SVARGMM_2_T1(2,outputelements))',... 
                     table2array(eval_SVARGMM_2_T1(3,outputelements))', ...  
                    table2array(eval_SVARGMM_2_T2(1,outputelements))',...
                    table2array(eval_SVARGMM_2_T2(2,outputelements))',... 
                     table2array(eval_SVARGMM_2_T2(3,outputelements))', ...  
                    table2array(eval_SVARGMM_2_T3(1,outputelements))',...
                    table2array(eval_SVARGMM_2_T3(2,outputelements))',... 
                     table2array(eval_SVARGMM_2_T3(3,outputelements))', ... 
                    ]   
                  ,
                  [   
                    table2array(eval_SVARGMM_3_T1(1,outputelements))',...
                    table2array(eval_SVARGMM_3_T1(2,outputelements))',... 
                     table2array(eval_SVARGMM_3_T1(3,outputelements))', ...  
                    table2array(eval_SVARGMM_3_T2(1,outputelements))',...
                    table2array(eval_SVARGMM_3_T2(2,outputelements))',... 
                     table2array(eval_SVARGMM_3_T2(3,outputelements))', ...  
                    table2array(eval_SVARGMM_3_T3(1,outputelements))',...
                    table2array(eval_SVARGMM_3_T3(2,outputelements))',... 
                     table2array(eval_SVARGMM_3_T3(3,outputelements))', ... 
                    ]   
                    , 
                  [   
                    table2array(eval_GMMLL_T1(1,outputelements))',...
                    table2array(eval_GMMLL_T1(2,outputelements))',... 
                     table2array(eval_GMMLL_T1(3,outputelements))', ...  
                    table2array(eval_GMMLL_T2(1,outputelements))',...
                    table2array(eval_GMMLL_T2(2,outputelements))',... 
                     table2array(eval_GMMLL_T2(3,outputelements))', ...  
                    table2array(eval_GMMLL_T3(1,outputelements))',...
                    table2array(eval_GMMLL_T3(2,outputelements))',... 
                     table2array(eval_GMMLL_T3(3,outputelements))', ... 
                    ]   
                    , 
                  [   
                    table2array(eval_PML_T1(1,outputelements))',...
                    table2array(eval_PML_T1(2,outputelements))',... 
                     table2array(eval_PML_T1(3,outputelements))', ...  
                    table2array(eval_PML_T2(1,outputelements))',...
                    table2array(eval_PML_T2(2,outputelements))',... 
                     table2array(eval_PML_T2(3,outputelements))', ...  
                    table2array(eval_PML_T3(1,outputelements))',...
                    table2array(eval_PML_T3(2,outputelements))',... 
                     table2array(eval_PML_T3(3,outputelements))', ... 
                    ]    
                  }
              
              
latex  = generateLatexTable(data)

