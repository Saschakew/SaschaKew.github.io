% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [options] = GenOptionsIRFPlot(options )

    %[options] = GenOptionsIRFPlot(options )
    %   
    % This function generates the input for the plotIRF() function
    %
    % Input:
        % options: possible inputs
            %IRFPlotOptions.alpha: quantile (e.g. {[0.2]})
            %IRFPlotOptions.PointEstimator = IRF point estimate (e.g. {Yimp})  
            %IRFPlotOptions.ConfidenceInterval = IRF simulated by bootstrap (e.g. {YimpBootstrap})       
            %IRFPlotOptions.shocklabels = Names of variables;       
    %
    % Output:
        % options:  
        
try
    options.PointEstimator ;     
catch
    disp('Please supply IRF')
end

try
    options.ConfidenceInterval      ;   
catch
    options.ConfidenceInterval = {   }    ;   
end
                    
try
    options.Color ;
catch
    options.Color = {  [0.1 0.1 0.1]   }   ; 
end  

try
    options.shocklabels  ;  
catch
    disp('Please supply labels')
end

try
    options.alpha  ; 
catch
    options.alpha = {0.10}; 
end

try
    options.shocks;
catch
    [~,~,n] =size( options.PointEstimator{1});
    options.shocks = [1:n];
end

try
    options.responses;
catch
    [~,n,~] =size( options.PointEstimator{1});
    options.responses = [1:n];
end
 

  
end

