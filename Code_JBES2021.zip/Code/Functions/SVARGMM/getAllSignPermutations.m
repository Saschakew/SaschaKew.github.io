% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [Y] = getAllSignPermutations(A)

    %[Y] = getAllSignPermutations(A)
    %   
    % This function calculates all signed permutations of the matrix A
    %
    % Input:
        % A: Input Matrix A
    %
    % Output:
        % Y: Matrix of signed permutations of A    
        
    [n,m] = size(A);
    
    Y = NaN(n,n,factorial(n)*2^n);
    % Get permutations of rows
    tmp = n:-1:1;
    permutations = perms(tmp); 
    counter = 0;
    I =eye(n);
    % Scale diagonal to 1
    for i = 1:factorial(n)
        Y_tmp = I(permutations(i,:),:) * A;
        
        signs = [];
        for j = 1:n
            sign = [];
            sign = [repmat(-1,2^n/(2^j),1);repmat(1,2^n/(2^j),1)];
            sign = repmat(sign,2^(j-1),1);
            signs = [signs, sign]; 
        end
        
        for j= 1:length(signs)
            counter = counter+1;
            Y(:,:,counter) = diag(signs(j,:)) * Y_tmp;
        end
        
        
         

    end