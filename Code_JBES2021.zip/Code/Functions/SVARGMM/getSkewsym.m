% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [S] = getSkewsym(q_vec)

   %[S] = getSkewsym(q_vec)
    %   
    % This function generates a skew symmetric matrix based on the vector q_vec
    %
    % Input:
        % q_vec: Vector
    %
    % Output:
        % S: skew symmetric matrix  
        
    n = ceil(sqrt(2*length(q_vec)));
    [ii jj] = ndgrid(1:n);  

    Q = zeros(n,n);
    Q(tril(true(size(Q)),-1)) = q_vec; 
    Q = Q-Q';

    S=Q;
end
