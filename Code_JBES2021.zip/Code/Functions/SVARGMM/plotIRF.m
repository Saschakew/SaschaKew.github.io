% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [] = plotIRF(IRF)

   % [] = plotIRF(IRF)
    %   
    % This function plots the impulse response function.    
        
    shocks = IRF.shocks;
    responses = IRF.responses;
  
    NumberOfSpecifications = length(IRF.PointEstimator)  ;  
    plotcounter = 0;
    figure 
    for thisShock = shocks
       for thisResponse = responses
           plotcounter = plotcounter + 1 ;
           for spec = 1:NumberOfSpecifications
                Yimp = IRF.PointEstimator{spec};
                try
                    Yimp_confidence = IRF.ConfidenceInterval{spec};
                catch
                    
                end
                
                try
                    Yimp_color = [0.1 0.1 0.1]; %IRF.Color{spec};
                catch
                    
                end
                
                alpha = IRF.alpha{spec}  ;
                    
                subplot(length(shocks),length(responses),plotcounter)
                
                Y = Yimp; 
                y = Y(:,thisResponse,thisShock);
                x = [0:length(y)-1];
                
                try
                    YIMP_lower = quantile(Yimp_confidence,1-alpha/2,4);
                    YIMP_upper = quantile(Yimp_confidence,alpha/2,4);
                    lower = YIMP_lower(:,thisResponse,thisShock)'; 
                    upper = YIMP_upper(:,thisResponse,thisShock)'; 
                     fill([x fliplr(x)],[upper fliplr(lower)], Yimp_color , 'FaceAlpha',0.6,'edgecolor','none')
                    hold on
                catch
                    
                end
                plot(x,y,'LineWidth',2,'Color',Yimp_color ) ;
                hold on
                
           end 
            hold on;
                hline = refline([0 0]);
                hline.Color = 'black';
                xlim([0 (length(y)-1)])
                set(gca,'fontsize',22);
                
            hold off
            str = strcat('\epsilon^{ ', IRF.shocklabels(thisShock), '} \rightarrow ', IRF.shocklabels(thisResponse) );
            title(str,'FontSize', 26);
       end
        
    end
    
    
    
    
    
end

