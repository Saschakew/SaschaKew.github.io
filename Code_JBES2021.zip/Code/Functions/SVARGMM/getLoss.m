% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [loss_T,f_T,W,options ] = getLoss(u,options )
  
   %[loss_T,f_T,W,options ] = getLoss(u,options )
    %   
    % GMM loss Function
    %
    % Input:
        % u: Residuals used to calculate moment conditions
        % options: 
    %
    % Output:
        % loss_T:  GMM loss function
        % f_T:   Moment conditions
        % W:   Weighting matrix of GMM loss function
        % options:    
        
        
% Moment Conditions
f_T = @(o_vec) mean( get_f(u,o_vec,options,false)     ,2);

% Weighting matrix
W = getWeighting(u,options.startvec,options);


% GMM Objective
loss_T = @(o_vec) f_T(o_vec)' * W *f_T(o_vec) ;
            
end

