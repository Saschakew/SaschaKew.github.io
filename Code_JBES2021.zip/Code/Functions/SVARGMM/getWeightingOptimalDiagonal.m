% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [W] = getWeightingOptimalDiagonal( u,o_vec,   options)


   % This function calculates a diagonal weighting matrix where each moment
   % is weighted with the inverse of its variance.
        
    f = get_f(u,o_vec,options,false)  ; 
    W = inv(diag(diag(cov(f') )));
end

