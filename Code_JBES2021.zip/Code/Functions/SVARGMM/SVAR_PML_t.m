% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [A_est,output] = SVAR_PML_t(u,options)
 
    %  [A_est,output] = SVAR_PML_t(u,options)
    %   
    % This function estimates the simulatenous interaction based on the PML
    % estimator.
        
% Whiten Data
[z,options] = whiten(u,options); 
% Log-Likelihood 
LL = @(o_hat) LogLikelihood_t_distribution(o_hat, u, options,options.degreeOfFreedom); 
 
o_est = [];
distance = [];
for i_startvec = 1:length(options.startvectors) 
    options.startvec = options.startvectors{i_startvec};
             
    % Optimization
    [o_est{i_startvec}, distance{i_startvec}] = GMMoptim(LL,options);
end
[~,theMin] = min(cell2mat(distance));
o_est = o_est{theMin};
distance = distance{theMin};


% Vector to matrix
A_est = getAMatrix(o_est, options)   ;
if options.PermuteIntoTheta
    % Get sign permutation representative
    A_est = SignPermRepresentative(A_est, options);
end 



% Calculate unmixed inovations
if options.GenUnmixedInnovations
    e = A_est * u'; e=e';
else
    e = NaN;
end


if options.GenStats
    [stats] = getStats(u,A_est,options);
else
    stats = NaN;
end
    
 
% Generate output
output = [];
output.options = options;

output.o_est = o_est;
output.B_est = inv(A_est);
output.A_est = A_est;
output.V_est = options.V;
%output.W = W;
output.e = e ; % unmixed innovation
output.distance = distance;

output.stats =  stats; 

 

end

