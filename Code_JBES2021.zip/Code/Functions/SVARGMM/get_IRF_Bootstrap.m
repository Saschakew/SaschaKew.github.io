% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [YIMP,A_est_boots] = get_IRF_Bootstrap(Y , ReducedFormVAROptions,  SVARGMMOptions, IRFOptions , BootstrapOptions)
                                                   
    %[YIMP,A_est_boots] = get_IRF_Bootstrap(Y , ReducedFormVAROptions,  SVARGMMOptions, IRFOptions , BootstrapOptions)
    %   
    % This function calculates bootstrap IRF functions based on the
    % ReducedFormVAROptions, SVARGMMOptions, IRFOptions and BootstrapOptions
    %
    % Input:
        % Y: 
        % ReducedFormVAROptions:
        % SVARGMMOptions: 
        % IRFOptions: 
        % BootstrapOptions: 
    %
    % Output:
        % Yimp:    
         
     
    [~,n] = size(Y);
       
    % Estimate reduced form
    ReducedFormVAR = EstReducedFormVAR(Y,ReducedFormVAROptions);
      
    % Estimate simultaenous interaction  
     [A_est ,output]= SVARGMM(ReducedFormVAR.Residuals,SVARGMMOptions);  
    % Save new start point
    new_startvec = output.o_est;
    
    
    % Create empty variables
    YIMP = NaN(IRFOptions.IRFlength,n,n,BootstrapOptions.NumIterations);
    A_est_boots = NaN(n,n,BootstrapOptions.NumIterations);
    % Start bootstrap iterations 
    parfor it = 1:BootstrapOptions.NumIterations
        disp(['Iteration  ', num2str(it), ' of ', num2str(BootstrapOptions.NumIterations)]);
         
        % Simulate new time series y_new 
        Y_simulated = SimulateVARData(ReducedFormVAR);
           
        %  Estimate new reduced form VAR 
        ReducedFormVAR_new = EstReducedFormVAR(Y_simulated,ReducedFormVAROptions);     

        %  Estimate bootstrap SVAR  
        thisSVARGMMOptions = SVARGMMOptions; 
        thisSVARGMMOptions.GenStats = false;
        thisSVARGMMOptions.startvec = new_startvec;  
        % Estimation 
         [A_est_it,output_it] = SVARGMM(ReducedFormVAR_new.Residuals,thisSVARGMMOptions); 
         
        % Find best permutation
        if BootstrapOptions.FindBestPermutation
            A_est_it = FindBestPermutation(A_est_it,A_est);
        end
        
        % IRF 
        this_IRFOptions = IRFOptions; 
        this_IRFOptions.variances = var(output_it.e)';
        %this_IRFOptions.variances = NaN;%diag(cov(output_it.e));
        Yimp   = get_IRF(A_est_it, ReducedFormVAR_new  , this_IRFOptions ) ;  

        % Save irf
        A_est_boots(:,:,it) = A_est_it;
        YIMP(:,:,:,it)= Yimp;  
    end
     
    
   
        
end

