% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de


function [D] = getDerivative(f,x,h)
%[D] = getDerivative(f,x,h)
%   Numerical approximation of Jacobian of f at x

    D = NaN(length(f(x)),length(x));
    for i = 1: length(x) 
        H = zeros(size(x));
        H(i) = h;
        D(:,i) = (f(x+H) - f(x)) ./ h; 
    end 
end

