% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [latex] = generateLatexTable(data)

    % [latex] = generateLatexTable(data)
    %
    % Generates the Latex tables in the paper.
    

latex = [];
for datacounter = 1:length(data.row) 
    this_row = data.row{datacounter};
    this_rowname = data.rowname{datacounter};
    this_estimator = data.estimator{datacounter};
    
    latex = [latex, '&$', this_rowname , num2str(this_row),   ' $'];
    for i = 1:length(this_estimator)
        latex = [latex,  '& $\underset{( ',num2str(this_estimator(2,i)), ' )}{ ', num2str(this_estimator(1,i)),' }$'];
    end
    latex = [latex, '\\'];
end



end
 