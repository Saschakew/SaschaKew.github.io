% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [ReducedForm] = EstReducedFormVAR(y,options)

    %[ReducedForm] = EstReducedFormVAR(y,options)
    %   
    % The function estimates the reduced form VAR.
    %
    % Input:
        % y: vector of time series  
        % options: Options include
            % options.NumLags: number of lags of the reduced form
            % options.Constant = True/False
            % options.Trend = True/False (a linear time trend)
            % options.Trend2 = True/False (a quadratic time trend)
    %
    % Output:
        % ReducedForm:      
            % ReducedForm.y: Input y
            % ReducedForm.AR: Estimated autoregressive part 
            % ReducedForm.const:  Estimated constant
            % ReducedForm.trend:  Estimated linear trend
            % ReducedForm.trend2:  Estimated quadratic trend
            % ReducedForm.Residuals:  Estimate residuals
            % ReducedForm.Sigma:  Estimated variance covariance matrix of
            % residuals
        

        
[~,n] = size(y);

% Get number of variables
ReducedForm.NumVariables = size(y,2); 
% Get number of lags
ReducedForm.NumLags = options.NumLags;

% Generate empty coefmat and residuals
coefmat = [];
u = [];

% Generate rhs
rhs = generate_rhs(y,options);

% OLS estimation for all variables
for i=1:n
   lhs = generate_lhs(y(:,i),options);
   
   mdl = fitlm(rhs,lhs,'Intercept',false); 
   beta = table2array(mdl.Coefficients(:,1));
   thisu = table2array(mdl.Residuals(:,1)) ;
   
   u=[u thisu];   
   coefmat = [coefmat; beta' ];
end

% Generate AR matrices
if options.Constant 
    const = coefmat(:,1);
    coefmat = coefmat(:,2:end);
else
    const = zeros(ReducedForm.NumVariables,1);
end
if options.Trend 
    trend = coefmat(:,1);
    coefmat = coefmat(:,2:end);
else
    trend = zeros(ReducedForm.NumVariables,1);
end
if options.Trend2 
    trend2 = coefmat(:,1);
    coefmat = coefmat(:,2:end);
else
    trend2 = zeros(ReducedForm.NumVariables,1);
end

AR = zeros(ReducedForm.NumVariables,ReducedForm.NumVariables,ReducedForm.NumLags);
for j = 1:ReducedForm.NumLags
    AR(:,:,j) = coefmat(:,1:ReducedForm.NumVariables);
    coefmat = coefmat(:,ReducedForm.NumVariables+1:end);
end

ReducedForm.y = y;

ReducedForm.AR = AR;
ReducedForm.const = const;
ReducedForm.trend = trend;
ReducedForm.trend2 = trend2;

ReducedForm.Residuals = u;

ReducedForm.Sigma = cov(u);

end

