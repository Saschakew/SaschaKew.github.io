% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function mat=infocrit(y,possibleLags,options)

    %mat=infocrit(y,possibleLags,options)
    %   
    % The function calcuates the SIC, AIC and HIC for a VAR.
    %
    % Input:
        % y: vector of time series  
        % possibleLags: vector of possible lag length
        % options: Reduced form VAR options            
            % options.Constant = True/False
            % options.Trend = True/False (a linear time trend)
            % options.Trend2 = True/False (a quadratic time trend)
    %
    % Output:
        % mat:  Matrix with SIC, AIC and HIC criteria 
        
k=size(y,2);
T=size(y,1)-max(possibleLags);
it = 0;

mat=[];
for order= possibleLags
     it = it +1;
    u = [];
    thisOptions = options;
    thisOptions.NumLags = order;
     
    % cut y such that all y have the same length
    thisY = y(max(possibleLags)+1-order:end,:); 
    % Estimate reduced form
    [thisReducedForm] = EstReducedFormVAR(thisY,thisOptions);
    u = thisReducedForm.Residuals;
    
    this_sic=log(det((u'*u)/T))+log(T)/T*(order*k^2+k);
	this_aic=log(det((u'*u)/T))+2/T*(order*k^2+k); 
	this_hic=log(det((u'*u)/T))+2/T*(order*k^2+k)*log(log(T));
    mat=[mat;[this_sic this_aic this_hic]];
end

mi=min(mat);
[chosenorders,~]=find(mat==ones(length(possibleLags),1)*mi);

disp('SIC AIC HIC');
disp(chosenorders');
disp('');
disp([(possibleLags)' mat]);



end