% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [rhs] = generate_rhs(y,options)

    %[lhs] = generate_rhs(y,options)
    %   
    % The function generates the right hand side of a VAR with n lags.
    %
    % Input:
        % y: vector of time series 
        % options: 
            % options.NumLags: number of lags of the reduced form
            % options.Constant = True/False
            % options.Trend = True/False (a linear time trend)
            % options.Trend2 = True/False (a quadratic time trend)
    %
    % Output:
        % rhs: Right hand side of VAR
        
        
    T=size(y,1);
    order = options.NumLags;
    rhs = [];
    
    for i = 1:order
       rhs  = [rhs, y(order+1-i:end-i,:)];       
    end
    
    if options.Trend2
        timetrend=1:(T-order);timetrend=timetrend';
        rhs = [timetrend.^2,  rhs]; 
    end
    if options.Trend
        timetrend=1:(T-order);timetrend=timetrend';
        rhs = [timetrend,  rhs]; 
    end
    if options.Constant
        const=ones(T-order,1);
        rhs = [const,  rhs]; 
    end    
           
end

