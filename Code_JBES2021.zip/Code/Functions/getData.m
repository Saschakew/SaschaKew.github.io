% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function data = getData(dispname ,flip,dateRow, dataRow,  timeInputFormat, timeFormat, time, input )

    % data = getData(dispname ,flip,dateRow, dataRow,  timeInputFormat, timeFormat, time, input )
    %
    % The function takes a table with input data and input dates. All dates
    % of the input time which apear in the input dates get assigned to the
    % corresponding input time. 
    %
    % Input:
        % input: Table containing data matrix and date vector
        % dispname: Name of the variable
        % flip: True/False, flip date and date upside down
        % dateRow: Row of the input table containing the data
        % dateRow: Row of the input table containing the date
        % timeInputFormat: Time formant of date row
        % timeFormat: Time formant of new date row
        % time: Time vector
    %
    % Output:
        % data: Data vector corresponding to time vector
    

    if flip
        input = flipud(input);
    end


    tmp.time = input(:,dateRow);
    tmp.time =  table2array(tmp.time);
    tmp.time =  datetime(tmp.time,'InputFormat',timeInputFormat,'Format',timeFormat);

    %tmp.timeYYYYMMDD = yyyymmdd(datetime(time(:),'InputFormat',timeFormat));


    data = NaN(size(time));
    data(ismember(time,tmp.time)) = table2array(input(ismember(tmp.time,time),dataRow));

    disp(['->Importing ' dispname ' (done)']) 


end







