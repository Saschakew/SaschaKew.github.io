% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

clc
clear
close all 
addpath(genpath('./Functions'));

rng(1);

%% General Settings
% Number of MC simulations
MClength = 10000;
% Timeloop
Tloop = [ 200,500 ,5000  ]; 
Momentlooplength = 3; 
Momentloop = {  % 200  
                [ 0,1, 0.22, 3 
                0,1, 0.22, 3 ]
                ,
                [ 0,1, 0.4, 3 
                0,1, 0.4, 3 ]
                ,
                [ 0,1, 0.68, 3 
                0,1, 0.68, 3 ]  
                , 
                % 500  
                [ 0,1, 0.14, 3 
                0,1, 0.14, 3 ]
                ,
                [ 0,1, 0.26, 3 
                0,1, 0.26, 3 ]
                ,
                [ 0,1, 0.41, 3 
                0,1, 0.41, 3 ]  
                , 
                % 5000  
                [ 0,1, 0.04, 3 
                0,1, 0.04, 3 ]
                ,
                [ 0,1, 0.08, 3 
                0,1, 0.08, 3 ]
                ,
                [ 0,1, 0.13, 3 
                0,1, 0.13, 3 ] 
                };

DataStartvec = -0.628;
n = 2; 
B = expm(getSkewsym(DataStartvec)); 
A = B \ eye(size(B));   




%% Estimator settings/options
o_startvec = {       0.628    };  
 

% Fast SVARGMM (3rd   moments)
Options_FSVARGMM = []; 
Options_FSVARGMM.whiten = true;
Options_FSVARGMM.W = 'fast'; % 
Options_FSVARGMM.Moments = [ get_Mr(3,n)];    
Options_FSVARGMM.PermuteIntoTheta = true;
Options_FSVARGMM.options.GenUnmixedInnovations = false;
Options_FSVARGMM.options.GenStats = false;
Options_FSVARGMM.MinOption = 'fminunc';
Options_FSVARGMM.startvectors = o_startvec;
Options_FSVARGMM = GenOptionsSVARGMM(Options_FSVARGMM,n);


 


%% MC
% Empty global solutions 
FSVARGMM  = NaN(n,n,MClength,Momentlooplength,length(Tloop));   

parfor it = 1:MClength  
    it
    
    % Empty solutions of this itertation 
    FSVARGMM_tmp = NaN(n,n,1,Momentlooplength,length(Tloop));   
    
    for Tloop_counter =  1 :  length(Tloop) 
         for Momentloop_counter = 1 : Momentlooplength 
             thisMomentloop =  Momentloop_counter + (Tloop_counter-1)*Momentlooplength
             
              % Unpack Settings  
                T = Tloop(Tloop_counter);
                this_moment = Momentloop(thisMomentloop)  ; 
                moments = this_moment{1};
                % Draw structural shocks
                eps = [];
                 for i = 1:n
                    eps_tmp = pearsrnd(moments(i,1),moments(i,2),moments(i,3),moments(i,4),T,1);
                    eps = [eps,  eps_tmp]; 
                 end 
                % Generate reduced form shocks
                u = B * eps'; u = u'; 
                %u = u - mean(u);
                
                % Estimations  
                [A_est_tmp ,output] = SVARGMM(u,Options_FSVARGMM);   
                A_est_tmp = FindBestPermutation(A_est_tmp, A   ); 
                FSVARGMM_tmp(:,:,:,Momentloop_counter ,Tloop_counter) =  A_est_tmp;
                
                 
                
             end
         
    end
    
     % Save solutions of this iteration to global solutions
    FSVARGMM(:,:,it,:,:) =FSVARGMM_tmp;  
end    
    
    
    
savestrg = ['MC_skewness.mat']
save(savestrg ); 
  
    
    
