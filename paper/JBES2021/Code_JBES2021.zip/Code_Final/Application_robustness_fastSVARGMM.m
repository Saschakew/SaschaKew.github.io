% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

%% This file generates the upper left IRF in Figure 1 in the online Appendix. 
%%
clc
clear
close all
addpath(genpath('./Data/Monthly'));
addpath(genpath('./Functions'));

rng(1);

 

%% Time
data.working.startYear = 1990;
data.working.endYear = 2018; 
time = transpose(datetime(data.working.startYear, 1, 1,'Format','yyyy-MM'):calmonths(1):datetime(data.working.endYear, 1, 1,'Format','yyyy-MM')); 

%% Import Data     
% Oil Price
data.raw.input = importfileOilCost('U.S._Crude_Oil_Composite_Acquisition_Cost_by_Refiners.csv', 6, 540);
data.raw.input = [table(datetime(table2array(data.raw.input(:,1)),'InputFormat','MMM yyyy','Format','yyyy-MM')),data.raw.input(:,2)];    
data.raw.oil_price = getData('Oil Price' ,true ,1,2, 'yyyy-MM','yyyy-MM', time , data.raw.input  );
% Industrial Prod
data.raw.input = importfileIndustProd('INDPRO.csv', 2, 1197);
data.raw.input = [table(datetime(table2array(data.raw.input(:,1)),'InputFormat','MMM yyyy','Format','yyyy-MM')),data.raw.input(:,2)]; 
data.raw.IndustProd = getData('Industrial Production' ,false ,1, 2, 'yyyy-MM-dd','yyyy-MM-dd',time , data.raw.input  );
% S&P 500 
data.raw.input = importfileSP500('^GSPC(1).csv', 2, 827); 
data.raw.input = [data.raw.input(:,1),data.raw.input(:,2)];
data.raw.sp = getData('S&P 500' ,false ,1, 2, 'yyyy-MM-dd','yyyy-MM-dd',time , data.raw.input  );
% CPI
data.raw.input =  importfileCPI('CPIAUCSL.csv', 2, 860);
data.raw.input = [data.raw.input(:,1),data.raw.input(:,2)];
data.raw.cpi = getData('CPI' ,false ,1, 2, 'yyyy-MM','yyyy-MM',time , data.raw.input  );

%% Data transformation    
% Deflate Oil and Stock prices
data.working.sp = 100* data.raw.sp ./ data.raw.cpi ;
data.working.oil_price = 100* data.raw.oil_price ./ data.raw.cpi ;
data.working.IndustProd = data.raw.IndustProd; 

% Return / Percentage Change
data.working.sp =  100*log( data.working.sp(2:end) ./ data.working.sp(1:end-1)); 
data.working.oil_price =       100*log(data.working.oil_price(2:end) ./    data.working.oil_price(1:end-1)); 
data.working.IndustProd =    100*log(   data.working.IndustProd(2:end) ./  data.working.IndustProd(1:end-1));

time = time(2:end);

% Choose Variables
mydata = table(  ...  
                    data.working.IndustProd,...  
                    data.working.oil_price,...
                    data.working.sp...
                   ); 

% Delete NaN rows
time = time(sum(isnan(table2array(mydata(:,2:end))),2)==0);
mydata = mydata( sum(isnan(table2array(mydata(:,2:end))),2)==0 ,:);

% Final data
X.data = table2array(mydata);
X.vnames = {  'EA' 'OP' 'SP'};
[~,X.numberOfVariables] = size(X.data);

clearvars data  mydata
    
    

 %% Stationary test (Dicky Fuller) 
%DickyFullerTest = table(X.vnames',[adftest(X.data(:,1));adftest(X.data(:,2));adftest(X.data(:,3));]);
%DickyFullerTest.Properties.VariableNames = {'Xnames'  'DFTest'}
    
%% Show data
if false
    figure 
    subplot(2,2,1)
    plot(time, (X.data(:,1)) ) 
    title(X.vnames(1)) 
    subplot(2,2,2)
    plot(time, (X.data(:,2)) )
    title(X.vnames(2)) 
    subplot(2,2,3)
    plot(time, (X.data(:,3)) )
    title(X.vnames(3)) 
end

%% Descriptive statistics
DescriptiveStatistics = table(X.vnames', mean(X.data)', median(X.data)',mode(X.data)',sqrt(var(X.data))', var(X.data)',skewness(X.data)',kurtosis(X.data)',range(X.data)' );
DescriptiveStatistics.Properties.VariableNames = {'Xnames'  'Mean'  'Median'  'Mode'  'StandardDeviation'  'Variance'  'Skewness'  'Kurtosis'  'Range'}

%% Estimate reduced form
% Options
ReducedFormVAROptions = [];
ReducedFormVAROptions.NumLags = 4;
ReducedFormVAROptions.Constant = true;
ReducedFormVAROptions.Trend = false;
ReducedFormVAROptions.Trend2 = false;
% Estimation
ReducedFormVAR = EstReducedFormVAR(X.data,ReducedFormVAROptions);
% Summarize residuals
summarizeResiduals(ReducedFormVAR.Residuals,X.vnames)
 
% 
infocrit(X.data,[1:12,24],ReducedFormVAROptions);
 

%% Estimation  
% Empty options
SVARGMMOptions = [];
 
SVARGMMOptions.whiten = true;
SVARGMMOptions.W = 'fast'; % 
SVARGMMOptions.Moments = [get_Mr(4,X.numberOfVariables);get_Mr(3,X.numberOfVariables)];    

% Manual options
SVARGMMOptions.startvectors =  {[0.0264 -0.3103 0.5741]};   
 
SVARGMMOptions.MinOption = 'both'; 
% Generate options
SVARGMMOptions = GenOptionsSVARGMM(SVARGMMOptions,X.numberOfVariables);
% Estimation 
[A_est,output] = SVARGMM(ReducedFormVAR.Residuals,SVARGMMOptions);
 
 
% Calculate IRF
IRFOptions.IRFlength = 12;
IRFOptions.variances = var(output.e)';
Yimp   = get_IRF( A_est, ReducedFormVAR, IRFOptions);

 % Bootstrap confidence intervals 
BootstrapOptions.NumIterations = 10000;
BootstrapOptions.FindBestPermutation = false;   
YimpBootstrap = get_IRF_Bootstrap(X.data , ReducedFormVAROptions,  SVARGMMOptions, IRFOptions , BootstrapOptions);


 % Plot IRF
IRFPlotOptions = [];
IRFPlotOptions.alpha = {[0.2]};
IRFPlotOptions.PointEstimator = {Yimp};  
IRFPlotOptions.ConfidenceInterval = {YimpBootstrap};       
IRFPlotOptions.shocklabels = X.vnames;                      
IRFPlotOptions = GenOptionsIRFPlot(IRFPlotOptions );
plotIRF(IRFPlotOptions) 

 
 