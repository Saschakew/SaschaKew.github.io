% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de
 

%%
clc
clear
close all 
addpath(genpath('./Functions'));

rng(1);

%% General Settings
% Number of MC simulations
MClength = 10000;
% Timeloop
Tloop = [ 200,500 ,5000  ]; 
Momentlooplength = 3; 
Momentloop = {  % 200 
                [ 0,1, 0, 5.33   
                0,1, 0, 5.33]
                ,
                [ 0,1, 0.68, 3
                 0,1, 0.68, 3]
                ,
                [ 0,1, 0, 3
                0,1, 0.68 , 5.33]  
                , % 500  
              [ 0,1, 0, 5.33   
                0,1, 0, 5.33]
                ,
                [ 0,1, 0.68, 3
                 0,1, 0.68, 3]
                ,
                [ 0,1, 0, 3
                0,1, 0.68 , 5.33]  
                 , % 5000 
               [ 0,1, 0, 5.33   
                0,1, 0, 5.33]
                ,
                [ 0,1, 0.68, 3
                 0,1, 0.68, 3]
                ,
                [ 0,1, 0, 3
                0,1, 0.68 , 5.33]  
                };

DataStartvec = -0.628;
n = 2; 
B = expm(getSkewsym(DataStartvec)); 
A = B \ eye(size(B));   





%% Estimator settings/options
o_startvec = { 2,1.8,1.6,1.4 ,1.2 ,1, 0.8, 0.6, 0.4 ,0.2,  0    }; 
A_startvec = {};
for i = 1:length(o_startvec)
    A_start_tmp = expm(getSkewsym(o_startvec{i})); 
    A_start_tmp =  A_start_tmp(:);  
    A_startvec{i} =  (A_start_tmp);
end


%  SVARGMM (1-step, identity weighting, 3rd & 4th moments)
Options_SVARGMM_1 = []; 
Options_SVARGMM_1.whiten = false; 
Options_SVARGMM_1.k_step_estimator = 1;   
Options_SVARGMM_1.PermuteIntoTheta = true;
Options_SVARGMM_1.options.GenUnmixedInnovations = false;
Options_SVARGMM_1.options.GenStats = false;
Options_SVARGMM_1.MinOption = 'both';
Options_SVARGMM_1.startvectors = A_startvec;
Options_SVARGMM_1 = GenOptionsSVARGMM(Options_SVARGMM_1,n);


%  SVARGMM (2-step, optimal weighting, 3rd & 4th moments)
Options_SVARGMM_2 = []; 
Options_SVARGMM_2.whiten = false; 
Options_SVARGMM_2.k_step_estimator = 2;    
Options_SVARGMM_2.PermuteIntoTheta = true;
Options_SVARGMM_2.options.GenUnmixedInnovations = false;
Options_SVARGMM_2.options.GenStats = false;
Options_SVARGMM_2.MinOption = 'both';
Options_SVARGMM_2.startvectors = A_startvec;
Options_SVARGMM_2 = GenOptionsSVARGMM(Options_SVARGMM_2,n);

 


% Fast SVARGMM (3rd & 4th moments)
Options_SVARGMM_3 = []; 
Options_SVARGMM_3.whiten = true;
Options_SVARGMM_3.W = 'fast'; % 
Options_SVARGMM_3.Moments = [get_Mr(4,n);get_Mr(3,n)];    
Options_SVARGMM_3.PermuteIntoTheta = true;
Options_SVARGMM_3.options.GenUnmixedInnovations = false;
Options_SVARGMM_3.options.GenStats = false;
Options_SVARGMM_3.MinOption = 'both';
Options_SVARGMM_3.startvectors = o_startvec;
Options_SVARGMM_3 = GenOptionsSVARGMM(Options_SVARGMM_3,n);



% GMM  (LL)
Options_GMMLL = []; 
Options_GMMLL.whiten = false; 
Options_GMMLL.k_step_estimator = 1;    
Options_GMMLL.Moments = [1 3;  get_Cr(2,n ) ; get_Mr(2, n ) ];  
Options_GMMLL.PermuteIntoTheta = true;
Options_GMMLL.options.GenUnmixedInnovations = false;
Options_GMMLL.options.GenStats = false;
Options_GMMLL.MinOption = 'both';
Options_GMMLL.startvectors = A_startvec;
Options_GMMLL = GenOptionsSVARGMM(Options_GMMLL,n); 


% PML 
Options_PML.n = n;
Options_PML.whiten = true;
Options_PML.degreeOfFreedom = [12 12];   
Options_PML.optionsmin = optimset('LargeScale','off','MaxFunEvals',5000,'Display','off','TolFun',1e-15,'TolX ',1e-15); 
Options_PML.PermuteIntoTheta = true;
Options_PML.GenUnmixedInnovations = false;
Options_PML.GenStats = false;
Options_PML.MinOption = 'both';
Options_PML.startvectors = o_startvec;


%% MC
% Empty global solutions
%SVARGMM_1 = NaN(n,n,MClength,Momentlooplength,length(Tloop));  
SVARGMM_2 = NaN(n,n,MClength,Momentlooplength,length(Tloop));   
SVARGMM_3 = NaN(n,n,MClength,Momentlooplength,length(Tloop));  
GMMLL = NaN(n,n,MClength,Momentlooplength,length(Tloop));  
PML = NaN(n,n,MClength,Momentlooplength,length(Tloop));  

parfor it = 1:MClength  
    it
    
    % Empty solutions of this itertation
    %SVARGMM_1_tmp  = NaN(n,n,1,Momentlooplength,length(Tloop)); 
    SVARGMM_2_tmp = NaN(n,n,1,Momentlooplength,length(Tloop));  
    SVARGMM_3_tmp = NaN(n,n,1,Momentlooplength,length(Tloop));  
    GMMLL_tmp = NaN(n,n,1,Momentlooplength,length(Tloop)); 
    PML_tmp = NaN(n,n,1,Momentlooplength,length(Tloop));  
    
    for Tloop_counter =  1 :  length(Tloop) 
         for Momentloop_counter = 1 : Momentlooplength 
             thisMomentloop =  Momentloop_counter + (Tloop_counter-1)*Momentlooplength
             
              % Unpack Settings  
                T = Tloop(Tloop_counter);
                this_moment = Momentloop(thisMomentloop)  ; 
                moments = this_moment{1};
                % Draw structural shocks
                eps = [];
                 for i = 1:n
                    eps_tmp = pearsrnd(moments(i,1),moments(i,2),moments(i,3),moments(i,4),T,1);
                    eps = [eps,  eps_tmp]; 
                 end 
                % Generate reduced form shocks
                u = B * eps'; u = u'; 
                %u = u - mean(u);
                
                % Estimations  
                %[A_est_tmp ,output] = SVARGMM(u,Options_SVARGMM_1);   
                %A_est_tmp = FindBestPermutation(A_est_tmp, A   ); 
                %SVARGMM_1_tmp(:,:,:,Momentloop_counter ,Tloop_counter) =  A_est_tmp;
                
                
                
                [A_est_tmp ,output] = SVARGMM(u,Options_SVARGMM_2);   
                A_est_tmp = FindBestPermutation(A_est_tmp, A   ); 
                SVARGMM_2_tmp(:,:,:,Momentloop_counter ,Tloop_counter) =  A_est_tmp;
                
                
                [A_est_tmp ,output] = SVARGMM(u,Options_SVARGMM_3);   
                A_est_tmp = FindBestPermutation(A_est_tmp, A   ); 
                SVARGMM_3_tmp(:,:,:,Momentloop_counter ,Tloop_counter) =  A_est_tmp;
                
                
                [A_est_tmp ,output] = SVARGMM(u,Options_GMMLL);   
                A_est_tmp = FindBestPermutation(A_est_tmp, A   ); 
                GMMLL_tmp(:,:,:,Momentloop_counter ,Tloop_counter) =  A_est_tmp;
                
                 
                [A_est_tmp ,output] = SVAR_PML_t(u,Options_PML);   
                A_est_tmp = FindBestPermutation(A_est_tmp, A   ); 
                PML_tmp(:,:,:,Momentloop_counter ,Tloop_counter) =  A_est_tmp;
                
                  
                
                
             end
         
    end
    
     % Save solutions of this iteration to global solutions
    %SVARGMM_1(:,:,it,:,:) =SVARGMM_1_tmp;  
    SVARGMM_2(:,:,it,:,:) =SVARGMM_2_tmp;      
    SVARGMM_3(:,:,it,:,:) =SVARGMM_3_tmp;   
    GMMLL(:,:,it,:,:) = GMMLL_tmp;   
    PML(:,:,it,:,:) = PML_tmp;    
end    



    
    
    
savestrg = ['MC.mat']
save(savestrg ); 
  
    
    
