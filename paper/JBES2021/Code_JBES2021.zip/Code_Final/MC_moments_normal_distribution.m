% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

%% Skewness and kurtosis of normal distribution in finite sample
% This file generates Table 2
%%
clc
clear
close all 
addpath(genpath('./Functions'));


% Number of MC iterations
m = 50000000; 
% Length of simulated samples
Tloop = [200 , 500, 5000];
% Longest simuated sample
Tmax = 5000;
% Create empty variables for skewness and kurtosis
skew_all = NaN(m,3);
kurt_all = NaN(m,3); 

% Simulate samples and save skewness/kurtosis
parfor i = 1:m
    x = randn(Tmax,1);
    for Tcounter = 1:3
        x_tmp = x(1:Tloop(Tcounter));
        skew_all(i,Tcounter) = skewness(x_tmp);
        kurt_all(i,Tcounter) = kurtosis(x_tmp);
    end
    
end 
 
% Quantiles  Skewness
QuantileSkewness = NaN(3,3); 
QuantileSkewness(1,:) = quantile(skew_all,0.9) ;
QuantileSkewness(2,:) = quantile(skew_all,0.99) ; 
QuantileSkewness(3,:) = quantile(skew_all,0.9999) ; 
 
 % Quantiles  Kurtosis
QuantileKurtosis = NaN(3,3); 
QuantileKurtosis(1,:) = quantile(kurt_all,0.9) ;
QuantileKurtosis(2,:) = quantile(kurt_all,0.99) ; 
QuantileKurtosis(3,:) = quantile(kurt_all,0.9999) ; 
 
 


 




