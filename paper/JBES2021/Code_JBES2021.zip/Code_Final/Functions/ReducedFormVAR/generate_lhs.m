% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [lhs] = generate_lhs(y,options)

    %[lhs] = generate_lhs(y,options)
    %   
    % The function generates the left hand side of a VAR with n lags.
    %
    % Input:
        % y: vector of time series 
        % options: 
            % options.NumLags: number of lags of the reduced form
    %
    % Output:
        % lhs: Input y with first options.NumLags observations dropped 
        
    order = options.NumLags;
    lhs = y(order+1:end);
end
