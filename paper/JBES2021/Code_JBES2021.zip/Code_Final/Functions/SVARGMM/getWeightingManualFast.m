% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [W] = getWeightingManualFast( z,o_vec,   options)

   % not implemented
        
    W = 1;%....
end

