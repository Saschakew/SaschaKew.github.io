% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [A] = getAMatrix(o_vec,options)

    %[A] = getAMatrix(o_vec,options)
    %   
    % This function generates a Matrix based on the Vector o_vec.  
    %
    % Input:
        % o_vec: Vector
        % options:
        %   whitening: True/False
    %
    % Output:
        % A: Matrix from vector o_vec   
        
        
if options.whiten
    O   = expm(getSkewsym(o_vec));
    A = O * inv(options.V);
else
    A  =  reshape(o_vec,[sqrt(length(o_vec)),sqrt(length(o_vec))]);  
end

 

end

