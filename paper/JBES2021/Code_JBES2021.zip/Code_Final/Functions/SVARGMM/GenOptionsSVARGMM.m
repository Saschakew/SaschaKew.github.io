% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [options] = GenOptionsSVARGMM(options,n)

    %[options] = GenOptionsSVARGMM(options )
    %   
    % This function generates the input for the SVARGMM() function
    %
    % Input:
        % options: possible options   
            % startvectors: e.g. {[1 0 0 1]}
            % k_step_estimator: number of GMM updates for weighting matrix 
            % MinOption: 'both'
            % n: 3
            % PermuteIntoTheta: True/False - permute estimated solution
            %   into set Theta
       	    % whiten: True/False - whitened SVAR-GMM
            % optionsmin: options used for fminunc() or fminsearch()
            % Moments: Moments and co-moments of the SVAR-GMM or fast
            % SVAR-GMM estimator (e.g. [1 0 1;1 1 0 ; 0 1 1] yields the
            %   thre covariance values in an SVAR with n=3)
            % W: Weighting matrix used in the first GMM step.
            %   ('identity','fast','optimal','optimal-diagonal' where 'fast' 
            %   is used for the fast SVAR-GMM estimator)  
            % GenStats: True/False - generate statistics on moments and
            %   co-moments
            % GenUnmixedInnovations: True/False - generate unmixed
            %   innovations
    %
    % Output:
        % options:      

try 
    options.n = n;
catch
   error('Error: options.n invalid.') 
end
 
% Weighting 1st step
try
    if ischar(options.W) 
        if sum(strcmp(options.W, {'identity','fast','optimal','optimal-diagonal'}))~=1
            disp('Warning: options.W invalid. Set options.W to identity')
            options.W = 'identity';
        end
    elseif ismatrix(options.W) 
        if ~isequal(size(options.W),size(NaN(length(options.Moments),length(options.Moments))))
             disp('Warning: options.W invalid. Set options.W to identity')
            options.W = 'identity';
        end
    else
        disp('Warning: options.W invalid. Set options.W to identity')
        options.W = 'identity';
    end
catch
    options.W = 'identity';
end
 
 % Whitening
try
    if ~islogical(options.whiten) 
        if isequal(options.W, 'fast')
            options.whiten = true;
            disp('Warning: options.whiten invalid. Set options.whiten to true')
        else
            options.whiten = false;
            disp('Warning: options.whiten invalid. Set options.whiten to false')
        end
    end
    
    if options.whiten == true && n <= 1
        disp('Warning: options.whiten invalid. Set options.whiten to false')
        options.whiten = false;
    end
catch
    if isequal(options.W, 'fast')
            options.whiten = true; 
    else
        options.whiten = false; 
    end
end

 
% Permute solution into Theta (set with unique solution)
try
    if ~islogical(options.PermuteIntoTheta)  
        disp('Warning: options.PermuteIntoTheta invalid. Set options.PermuteIntoTheta to false')
        options.PermuteIntoTheta = false;
    end
catch
    options.PermuteIntoTheta = false;
end



% k-step GMM
try 
    if options.k_step_estimator ~= round(options.k_step_estimator)
        disp('Warning: options.k_step_estimator invalid. Set options.k_step_estimator to 1')
        options.k_step_estimator = 1;
    end
catch
    options.k_step_estimator = 1;
end

 

% MinOption 
try
    if sum(strcmp(options.MinOption, {'fminsearch','fminunc','both'}))~=1
         disp('Warning: options.MinOption invalid. Set options.MinOption to fminunc')
         options.MinOption = 'fminunc';
    end
catch
    options.MinOption = 'fminunc';
end



% Options for fminsearch,fminunc or fmincon
try
    options.optionsmin;
catch
    options.optionsmin = optimset('LargeScale','off','MaxFunEvals',10000,'Display','off','TolFun',1e-15,'TolX ',1e-15,'UseParallel',true);
end
 
 

% Moment conditions
try
    [~,ntmp] = size(options.Moments );
     if ntmp ~= n
         disp('Warning: options.Moments invalid. Set options.Moments to default')
            if options.whiten
                options.Moments =  [get_Mr(4, n );  get_Mr(3, n );   ];   
            else
                options.Moments =  [get_Cr(4, n );  get_Cr(3, n );  get_Cr(2,n ) ; get_Mr(2, n )   ];   
            end
     end
catch
    if options.whiten
         options.Moments =  [get_Mr(4, n );  get_Mr(3, n );   ];   
    else
        options.Moments =  [get_Cr(4, n );  get_Cr(3, n );  get_Cr(2,n ) ; get_Mr(2, n )   ];   
    end
end




 
% startvectors
try
     options.startvectors 
catch
    if options.whiten 
        options.startvectors =   {zeros(1,n*(n-1)/2)}; 
    else
        I = eye(n);
        options.startvectors = {I(:)'};
    end
end 



% Generate stats (mean and std of var-, cov-, cos- and cok- momentconditions)
try
    if ~islogical(options.GenStats) 
        disp('Warning: options.GenStats invalid. Set options.GenStats to true')
        options.GenStats = true;
    end
catch
    options.GenStats = true;
end



% Generate unmixed innovations  
try
    if ~islogical(options.GenUnmixedInnovations) 
        disp('Warning: options.GenUnmixedInnovations invalid. Set options.GenUnmixedInnovations to true')
        options.GenUnmixedInnovations = true;
    end
catch
    options.GenUnmixedInnovations = true;
end

 


end

