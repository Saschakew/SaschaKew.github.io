% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [stats] = getStats(u,A,options)

   %[stats] = getStats(u,A,options)
    %   
    % This function generate statistics on moments and co-moments
    %
    % Input:
        % u: Residuals
        % A: Mixing matrix
        % options: 
            % options.Moments: Moments to evaluate
    %
    % Output:
        % stats:   
        

options_tmp = options; 
 

options_tmp.Moments = get_Mr(2,options.n);
Moments = options_tmp.Moments;
MeanMoments =  mean( get_f(u,A,options_tmp,true),2);
StdMoments = std(get_f(u,A,options_tmp,true)')';
stats.VarianceMomentConditions = table(Moments,MeanMoments,StdMoments );

options_tmp.Moments = get_Cr(2,options.n);
Moments = options_tmp.Moments;
MeanMoments =  mean( get_f(u,A,options_tmp,true),2);
StdMoments = std(get_f(u,A,options_tmp,true)')';
stats.CovarianceMomentConditions = table(Moments,MeanMoments,StdMoments );

options_tmp.Moments = get_Cr(3,options.n);
Moments = options_tmp.Moments;
MeanMoments =  mean( get_f(u,A,options_tmp,true),2);
StdMoments = std(get_f(u,A,options_tmp,true)')';
stats.CoskewnessMomentConditions = table(Moments,MeanMoments,StdMoments );

options_tmp.Moments = get_Cr(4,options.n);
Moments = options_tmp.Moments;
MeanMoments =  mean( get_f(u,A,options_tmp,true),2);
StdMoments = std(get_f(u,A,options_tmp,true)')';
stats.CokurtosisMomentConditions = table(Moments,MeanMoments,StdMoments );

 


end

