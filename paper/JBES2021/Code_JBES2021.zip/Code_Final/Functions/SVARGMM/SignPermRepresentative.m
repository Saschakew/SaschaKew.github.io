% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [A_est] = SignPermRepresentative(A_est,options)
 
   %  [A_est] = SignPermRepresentative(A_est,options)
    %   
    % Permutates a Matrix A_est into Theta.   
        
    n = options.n;
    
    for i = 1:n-1
       [~,ind] = max(abs(A_est(i:end,i))) ;
       thisPerm = 1:n;
       thisPerm(i) = (i-1)+ind;
       thisPerm((i-1)+ind) = i;
       A_est = A_est(thisPerm,:);
    end
     A_est = sign(diag(diag(A_est))) * A_est   ; 
end
