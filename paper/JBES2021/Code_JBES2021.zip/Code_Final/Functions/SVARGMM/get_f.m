% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [f] = get_f(u,o_vec,options,Ainput)  

    %[f] = get_f(u,o_vec,options,Ainput)  
    %   
    % This function calculates the sample moments of the GMM function
    %
    % Input:
        % u: VAR residuals
        % o_vec: vector generating A Matrix at wich moments are evaluated 
        % options: sample moments are calculated
        % Ainput: True/False - False -> use getAMatrix(o_vec,options) to
        %   generate A Matrix from o_vec
        %   True -> use o_vec as A Matrix
    %
    % Output:
        % f:  sample moments of the GMM function  
        
Moments = options.Moments;
whiten = options.whiten; 

[~,n] = size(Moments);

if Ainput
    O = o_vec;
else
    O = getAMatrix(o_vec,options);
end 

% Calculate structural shocks implied by A
e = O * transpose(u); e = transpose(e);

f = [];
f_indep = [];
for moment = Moments'
   f_tmp = (e.^(moment')); 
   f = [f; prod(f_tmp')]; 
   
   
   if sum(moment==0)== (n-1) 
       % Moment is not a co-moment
       if ismember(2,moment)
           % If variance, set variance to 1
           f_indep_tmp = 1;
       elseif ismember(3,moment)
           % If not variance, set no moment condition (used in fast
           % version) 
           f_indep_tmp = 0;
       elseif ismember(4,moment)
           % If not variance, set no moment condition (used in fast
           % version) 
           f_indep_tmp = 3;
       end
   else
       % Moment is a co-moment 
       if ismember(1,moment)
           f_indep_tmp = 0;
       else
           f_indep_tmp =1;
       end 
   end
   
   f_indep = [f_indep; f_indep_tmp];
   
   
end


f = f-f_indep;


end

