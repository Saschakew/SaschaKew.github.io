% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [Cr] = get_Cr(r,n)

    %[Cr] = get_Cr(r,n)
    %   
    % This function generates the co-moments C(r)
    %
    % Input:
        % r: order
        % n: number of variables
    %
    % Output:
        % Cr: co-moments  

        
SelectMoments = unique(sort(nchoosek(repmat([1:n],1,r),r),2),'rows')  ;
Cr = NaN(length(SelectMoments),n);
for i = 1:n
    Cr(:,i) = sum(SelectMoments ==  i,2); 
end
Cr = Cr( sum(Cr<r,2)==n,: );

end

