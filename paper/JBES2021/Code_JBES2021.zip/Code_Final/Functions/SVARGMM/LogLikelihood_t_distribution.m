% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [loglike] = LogLikelihood_t_distribution(o_vec, u, options,v)
 
   % [loglike] = LogLikelihood_t_distribution(o_vec, u, options,v)
    %   
    % This function calculates the Log-Likelihood-Function of the PML
    % estimator based on a t-distribution.
    %
    % Input:
        % o_vec:  Used to generate unmixing matrix A
        % u: residuals
        % options: 
            % v: degrees of freedom of t distribution
    %
    % Output:
        % loglike: Log-Likelihood-Function     
          
O = getAMatrix(o_vec,options);
% Calculate structural shocks implied by A
e = O * transpose(u); e = transpose(e);   
v = repmat(v,length(e),1); 
loglike =  sum(sum( (-1*(1-v)/2)  .*  log(   1+ (e.^2)./(v-2)     )      ))  ;
 
end

