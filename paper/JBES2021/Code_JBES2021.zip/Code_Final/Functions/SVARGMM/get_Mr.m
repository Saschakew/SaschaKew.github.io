% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [Mr] = get_Mr(r,n)


    %[Mr] = get_Mr(r,n)
    %   
    % This function generates the  moments M(r)
    %
    % Input:
        % r: order
        % n: number of variables
    %
    % Output:
        % Cr:  moments  
 
    Mr = eye(n)*r; 

end
