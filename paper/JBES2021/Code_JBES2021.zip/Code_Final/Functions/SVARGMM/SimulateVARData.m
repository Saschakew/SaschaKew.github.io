% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [Y_simulated] = SimulateVARData(ReducedFormVAR)

    %  [Y_simulated] = SimulateVARData(ReducedFormVAR)
    %   
    % This function simulates time series corresponding to the estimated
    % reduced form. 
    % 
        
[T,n] = size(ReducedFormVAR.Residuals);

sample_index =  randsample(1:T,T,true);
Residuals_new = ReducedFormVAR.Residuals(sample_index,:); 
p = ReducedFormVAR.NumLags;

const = ReducedFormVAR.const;
trend = ReducedFormVAR.trend;
trend2 = ReducedFormVAR.trend2; 
AR = ReducedFormVAR.AR;

% Create new Y timeseries
Y_new = NaN(size(ReducedFormVAR.y)); 
Y_new(1:p,:) = ReducedFormVAR.y(1:p,:) ; 
for i=p+1:T+p  
    tmpsum = const + trend .* (i-p) + trend2 .* (i-p);
    for j = 1:p
        tmpsum = tmpsum +    AR(:,:,j) * Y_new(i-j,:)' ;
    end 
    tmpsum =     tmpsum +   Residuals_new(i-p,:)';
    Y_new(i,:) = tmpsum'; 
end 
 
Y_simulated = Y_new;
end

