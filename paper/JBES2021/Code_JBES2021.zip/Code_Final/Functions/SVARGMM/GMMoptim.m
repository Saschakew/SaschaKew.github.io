% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [o_est,distance] = GMMoptim(loss_T, options)
  
   % [o_est,distance] = GMMoptim(loss_T, options)
    %   
    % This function calculates the minima of the GMM loss function.
    %
    % Input:
        % loss_T:  GMM loss function
        % options: 'both', 'fminsearch', 'fminunc' ->   optimization routine 
    %
    % Output:
        % o_est: GMM minima  
        % distance: Value of GMM loss function at minima   
        
  optionsmin = options.optionsmin;
    
  if isequal(options.MinOption,'both')  
        
        [o_est_fminsearch,distance_fminsearch]=fminsearch( loss_T ,  options.startvec, optionsmin); 
        [o_est_fminunc,distance_fminunc]=fminunc( loss_T ,  options.startvec, optionsmin); 
        
        if distance_fminsearch<=distance_fminunc
        	distance = distance_fminsearch;
            o_est = o_est_fminsearch ;
        else
            distance = distance_fminunc;
            o_est = o_est_fminunc ;
        end
        
    elseif isequal(options.MinOption,'fminsearch')   
        [o_est,distance]=fminsearch( loss_T ,  options.startvec, optionsmin); 
    elseif isequal(options.MinOption,'fminunc')   
        [o_est,distance]=fminunc( loss_T ,  options.startvec, optionsmin); 
    end 
    
    
    
 
end

