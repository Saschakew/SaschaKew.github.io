% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [o_vec] = getAVector(A,options)

    %[o_vec] = getAVector(A,options)
    %   
    % This function generates a vector o_vec based on the Matrix A.  
    %
    % Input:
        % A: Matrix
        % options:
        %   whitening: True/False
    %
    % Output:
        % o_vec: Vector generated from A Matrix   
        
    O =  A *  (options.V) ;

    if options.whiten
        L = tril(ones(size(O)),-1);
        o_vec = logm(O); 
        o_vec = o_vec(L==1)';
    else 
        o_vec = O(:) ;
    end 
    
    
end

