% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [summary] = summarizeResiduals(Residuals,vnames)

    %  [summary] = summarizeResiduals(Residuals,vnames)
    %   
    % This function calculates the variance, skewness, kurtosis and
    % Jarque�Bera test of a vector of residuals.
        

pvalue = NaN(length(vnames),1);
for i = 1:length(vnames)
    [~,pv] = jbtest(Residuals(:,i));  
    pvalue(i) = pv;
end     

summary = table( vnames', var(Residuals)', skewness(Residuals)', kurtosis(Residuals)', pvalue );
summary.Properties.VariableNames = {'vnames'  'Variance'  'Skewness'  'Kurtosis' 'JBTest'};
    
end

