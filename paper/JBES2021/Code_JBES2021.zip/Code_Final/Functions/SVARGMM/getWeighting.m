% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [W] = getWeighting(z,o_vec,options)

   %[W] = getWeighting(z,o_vec,options)
    %   
    % This function generates the GMM weighting matrix.
    %
    % Input:
        % z: Residuals
        % o_vec: Used to generate unmixing matrix A
        % options: 
            % options.W:  'identity','fast','optimal','optimal-diagonal' where 'fast' 
            %   is used for the fast SVAR-GMM estimator   
    %
    % Output:
        % W: Weighting matrix  
        
if ischar(options.W)
    if strcmp(options.W, 'identity') 
        W = eye(size(options.Moments,1));
   elseif strcmp(options.W, 'fast') 
        W = -1;
    elseif strcmp(options.W, 'manual_fast') 
        W = getWeightingManualFast( z,o_vec,   options) ;
    elseif strcmp(options.W, 'optimal')
        W =  getWeightingOptimal( z,o_vec,   options) ;
    elseif strcmp(options.W, 'optimal-diagonal')
        W =  getWeightingOptimalDiagonal( z,o_vec,   options) ;
    end
else
    W = options.W;
end

end

