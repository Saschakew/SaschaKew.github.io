% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [ Yimp ] = get_IRF( A, ReduvedFormVAR, options)

    %[ Yimp ] = get_IRF( A, ReduvedFormVAR, options)
    %   
    % This function calcuates the IRF based on the AR part of the VAR and
    % on the simultaenous interaction A
    %
    % Input:
        % A: Simulatenous interaction 
        % ReduvedFormVAR: Output of EstReducedFormVAR(y,options)
        % options: 
            % IRFOptions.IRFlength: lag length;
            % IRFOptions.variances: variance covariance of structural
                % shocks used as impact of initial shocks
    %
    % Output:
        % Yimp: Impulse Response Function (used in  plotIRF())  
        
    B = inv(A);
    irflength = options.IRFlength;
    variances = options.variances;
    AR = ReduvedFormVAR.AR;
    
    % create phi variable
    phi = NaN(length(B),length(B),irflength);
    % first phi
    if isnan(variances)
        phi(:,:,1) = eye(length(B),length(B));
    else  
        phi(:,:,1) =  diag(sqrt(variances)); 
    end
    
    % all other phi...loop over irflength
    for i=2:irflength
        tmpsum = zeros(length(B),length(B));
        for j=1:i-1
            if j <= ReduvedFormVAR.NumLags
                tmpsum = tmpsum + phi(:,:,i-j)*AR(:,:,j);
            end
        end
        phi(:,:,i) = tmpsum;
    end
    
    for i=1:irflength 
        phi(:,:,i) =    phi(:,:,i) *B  ;
    end
    
    % create Yimp
    Yimp = NaN(irflength,length(B),length(B));
    for i=1:length(B)
        for j=1:irflength
            Yimp(j,:,i) = phi(:,i,j);
        end
        
    end
    
end

