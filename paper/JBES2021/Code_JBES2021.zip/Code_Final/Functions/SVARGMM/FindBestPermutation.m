% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [A_best] = FindBestPermutation(A_est,A)
 
    
    %mat=infocrit(y,possibleLags,options)
    %   
    % This function finds the (row) sign permutation of A_est closest (Frobeniusnorm) to A
    %
    % Input:
        % A_est:  Estimated Matrix A_est
        % A:   True Matrix
    %
    % Output:
        % A_best:  Signed permutation of A_est closest to A
             
    
    AllPermutations = getAllSignPermutations(A_est);
    [~,~,J] = size(AllPermutations);
    deviation_vector = NaN(J,1);
    for j=1:J
        thisA = AllPermutations(:,:,j);  
        deviation =  ((thisA)-(A)).^2;
        deviation = sum(sum(deviation)) ; 
        
        deviation_vector(j) = deviation;
    end
    [~,bestFit] = min(deviation_vector); 
    A_best = AllPermutations(:,:,bestFit) ;
end

