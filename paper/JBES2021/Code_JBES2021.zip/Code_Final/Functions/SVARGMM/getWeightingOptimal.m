% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [W] = getWeightingOptimal( u,o_vec,   options)

   %[W] = getWeightingOptimal( u,o_vec,   options)
    %   
    % This function calculates an estimate of the asymptotically efficient
    % weighting matrix 
        
    f = get_f(u,o_vec,options,false)  ; 
    W = inv(((cov(f') )));
end

