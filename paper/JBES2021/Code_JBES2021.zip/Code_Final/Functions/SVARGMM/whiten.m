% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

function [z,options] = whiten(u,options)

    %  [z,options] = whiten(u,options)
    %   
    % This function calculates the whitened residuals and the Cholesky
    % decomposition V of the variance covariance matrix of the residuals.
        
[T,n] = size(u);
 Sigma = (u' * u)./T;
    if options.whiten
        V=(chol(Sigma,'lower'));
        invV = (V)\eye(size(cov(u)))    ;  
    else
        invV = eye(size(Sigma));
        V = eye(size(Sigma));
    end  
    z = invV * u'; z=z';   
    
    options.V = V;
end

