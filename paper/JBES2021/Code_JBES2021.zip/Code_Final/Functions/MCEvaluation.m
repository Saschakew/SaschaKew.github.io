% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de


function [Output] = MCEvaluation(B, A_est, element,T)

    %[Output] = MCEvaluation(B, A_est, element,T)
    %   
    % The function repots the bias, standard deviation, scaled bias and
    % scaled standard deviation of the estimated element A_est(element).
    % The scaling is equal to sqrt(T).
    %
    % Input:
        % B: True Matrix B equalo to A_0^{-1} 
        % A_est:  Estimat of A_0
        % element: Element of estimate at which estimation is evaluated 
        % T: Sample size 
    %
    % Output:
        % Output:  bias, standard deviation, scaled bias and scaled standard deviation

[n,m,MClength,SettingsLength] = size(A_est);
A=inv(B); 
Bias = NaN(SettingsLength,1);
Bias_T = NaN(SettingsLength,1);
SD = NaN(SettingsLength,1);  
SD_T = NaN(SettingsLength,1);  

for iSettings = 1: SettingsLength
    B_est = NaN(n,m,MClength);
    B_est_element = NaN(1,MClength);
    A_est_element = NaN(1,MClength);
    for it=1:MClength
        B_est(:,:,it) = A_est( :, :,  it,iSettings)\eye(n);
        B_est_element(it) = B_est( element(1), element(2),  it);
        A_est_element(it) = A_est(element(1), element(2),  it,iSettings);
    end
    
    
    B_element = B(element(1), element(2));
    A_element = A(element(1), element(2));
    if true
        theDiff =  B_est_element - B_element    ;
        
        Bias(iSettings) = round( mean( (theDiff)),2);
        SD(iSettings) = round(sqrt(mean(  (B_est_element-B_element).^2  )),2);
        
        
        Bias_T(iSettings) = round( mean( sqrt(T)*(theDiff)),2);
        SD_T(iSettings) = round(var( sqrt(T)* (B_element-B_est_element)  ),2);
    else
        theDiff =  A_est_element - A_element    ;
        Bias(iSettings) = round( mean( (theDiff)),2);
        SD(iSettings) = round(sqrt(mean(  (A_est_element-A_element).^2  )),2);

        Bias_T(iSettings) = round( mean( sqrt(T)*(theDiff)),2);
        SD_T(iSettings) = round(var( sqrt(T)* (A_element-A_est_element)  ),2);;
    end
     
end

 Output = table(Bias, SD, Bias_T, SD_T); 

end

