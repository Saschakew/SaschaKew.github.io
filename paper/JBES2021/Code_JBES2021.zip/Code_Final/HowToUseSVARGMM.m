% Code for "A Generalized Method of Moments Estimator for Structural Vector 
% Autoregressions Based on Higher Moments" by Sascha Alexander Keweloh 
% Author: Sascha Alexander Keweloh  sascha.keweloh@tu-dortmund.de

%% Example: How to estimate the SVAR-GMM and fast SVAR-GMM estimator


%% 
clc
clear
close all 
addpath(genpath('./Functions'));
 
%% Simulate Data
n = 2; %number of variables
T = 5000; % sample size
A = eye(n);   
B = inv(A);
moments = [0 1 1 6; 
           0 1 1 6]; % moments of structural shocks (mean variance skewness kurtosis)
% Draw structural shocks
eps = [];
 for i = 1:n
    eps_tmp = pearsrnd(moments(i,1),moments(i,2),moments(i,3),moments(i,4),T,1);
    eps = [eps,  eps_tmp]; 
 end 
% Generate reduced form shocks
u = B * eps'; u = u'; 

%% Estimation SVAR-GMM (two-step) 
options = []; 
options.k_step_estimator = 2;
options = GenOptionsSVARGMM(options,n);
[A_est ,output] = SVARGMM(u,options);   


%% Estimation SVAR-GMM (two-step, only fourth co-moments ) 
options = []; 
options.k_step_estimator = 2;
options.Moments = [get_Mr(2,n);get_Cr(2,n);get_Cr(4,n);];
options = GenOptionsSVARGMM(options,n);
[A_est ,output] = SVARGMM(u,options);   

%% Estimation fast SVAR-GMM   
options = []; 
options.W = 'fast';
options.whiten = true;
options = GenOptionsSVARGMM(options,n);
[A_est ,output] = SVARGMM(u,options);   

%% Estimation fast SVAR-GMM  (only fourth moments)
options = []; 
options.W = 'fast';
options.whiten = true;
options.Moments = [get_Mr(4,n)];
options = GenOptionsSVARGMM(options,n);
[A_est ,output] = SVARGMM(u,options);   














